# a = 1
# while a < 100:
#     if a % 2 == 0:
#         print(a, " e' un numero pari")
#     else:
#         print(a, " e' un numero dispari")
#     a = a + 1
        
#for a in range(1, 100, 1):
lista = [1,3,56,45678,48,245,467,2456,46978]
for a in lista:
    # if a % 2 == 0:
    #     print(a, " e' un numero pari")
    # else:
    #     print(a, " e' un numero dispari")
    print(a, " e' un numero pari" if a % 2 == 0 else " e' un numero dispari")
    
l = [str(a) + (" e' un numero pari" if (a % 2 == 0) else " e' un numero dispari") for a in lista ]
print(l)

print("Fine del programma")
