import string
# se il numero � minore di 20 -> esiste solo una tabella che converte
def __trans_20(number: int) -> string:
    units = [
        "uno",
        "due",
        "tre",
        "quattro",
        "cinque",
        "sei",
        "sette",
        "otto",
        "nove",
        "dieci",
        "undici",
        "dodici",
        "tredici",
        "quattordici",
        "quindici",
        "sedici",
        "diciassette",
        "diciotto",
        "diciannove",
    ]
    return units[number - 1]

#   se il numero � tra 20 e 100 (escluso) ->
#   per la decina si deve usare una tabella (venti, trenta,..., novanta)
#   per la unit� si pu� usare la parte di algoritmo con la quale abbiamo risolto il problema nell'intervallo [1..20[
def __trans_100(number: int) -> string:
    if number < 20:
        return __trans_20(number)
    decs = [
        "venti",
        "trenta",
        "quaranta",
        "cinquanta",
        "sessanta",
        "settanta",
        "ottanta",
        "novanta",
    ]
    return decs[number // 10 - 2] + __trans_20(number % 10)

#   se il numero � tra 100 e 1000 (escluso) ->
#	si traducono le centinaia (cento, due cento, tre cento...)
#	poi le decine si traducono con l'algoritmo dell'intervallo [20, 100[
def __trans_1000(number: int) -> string:
    if (number < 100):
        return __trans_100(number)
    t = number // 100
    d = number % 100
    return ("cento" if t == 1 else __trans_100(t) + "cento") + __trans_100(d)

def __trans_1000000(number: int) -> string:
    if (number < 1000):
        return __trans_1000(number)
    h = number // 1000
    t = number % 1000
    return ("mille" if h == 1 else __trans_1000(h) + "mila") + __trans_1000(t)

def translate(number: int) -> string:
    if number == 0:
        return "zero"
    if number < 0:
        return "meno " + translate(-number)
    if number < 1000000:
        return __trans_1000000(number)
    return "overflow"

numeri_fino_a_20000 = list(range(1, 20000, 1))
l = [translate(x) for x in numeri_fino_a_20000]
#print(l)

units = [
    "uno",
    "due",
    "tre",
    "quattro",
    "cinque",
    "sei",
    "sette",
    "otto",
    "nove",
    "dieci",
    "undici",
    "dodici",
    "tredici",
    "quattordici",
    "quindici",
    "sedici",
    "diciassette",
    "diciotto",
    "diciannove",
]
print(units[3])

n = [1,3,4,6,2,3267,1346,36]
l = [x for x in n if x % 2 == 0]
print (l)