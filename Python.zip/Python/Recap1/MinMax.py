# occorre calcolare il valore massimo contenuto all'interno di una lista
# scrivendo una funzione max che accetti in input la lista e restitusca
# il valore pi� alto in essa contenuto
# ovviamente non usare funzioni di sistema che possano produrre lo stesso risultato

from numbers import Number


def _max(numbers):
    #   a = [isinstance(x, Number) for x in numbers]
    #   print(a)
    if (  # coerenza del dominio del parametro di input
        not type(numbers) is list  # deve essere una lista
        or len(numbers) == 0  # non deve essere vuota
        # e gli elementi devono essere tutti numeri
        or any(  # restituisce True se almeno un elemento della lista passata come parametro � posto a True
            # crea una lista nella quale c'� False quando siamo in presenza di un Number,
            # True se c'� un dato diverso da un Number
            [not isinstance(x, Number) for x in numbers]
        )
    ):
        return "ND"

    m = numbers[0]  # suppongo inizialmente che il primo numero sia il pi� grande
    for i in numbers:  # attraverso tutti i numeri
        if m < i:  # se ne trovo uno pi� grande,
            m = i  # allora lo sostituisco a quella che era la supposizione iniziale
    return m  # dentro m ci sar� il numero pi� alto


def _min(numbers):
    if (
        not type(numbers) is list
        or len(numbers) == 0
        or any([not isinstance(x, Number) for x in numbers])
    ):
        return "ND"

    m = numbers[0]
    for i in numbers:
        if m > i:
            m = i
    return m


def _avg(numbers):
    if (
        not type(numbers) is list
        or len(numbers) == 0
        or any([not isinstance(x, Number) for x in numbers])
    ):
        return "ND"
    return (_min(numbers) + _max(numbers)) / 2


print(_max([123, 324, 367, 1243, 67824, 32145, 247678, -1, 21431, -145]))
print(_max("Pippo"))
print(_max(["Pippo", "Pluto", "Paperino"]))
print(_min([123, 324, 367, 1243, 67824, 32145, 247678, -1, 21431, -145]))
print(_avg([123, 324, 367, 1243, 67824, 32145, 247678, -1, 21431, -145]))
