# creare una lista contenente tutti i numeri primi compresi tra
# 2 e un numero passato come parametro ad una funzione

def sieve(max):
    if not type(max) is int or max < 2: # test di congruenza del dominio di "max" (numero intero >= 2)
        return []
    
    _range = range(2,max,1) # tutti i numeri da 2 a max (escluso)
    _primes = [True for x in _range] # una lista con tutti true e lunga quanto _range
    for i in _range: # scorro _range
        if _primes[i-2]: # se l'elemento in _primes alla posizione i � posto a True (il -2 serve per aggiustare l'indice per accedere a _primes)
            for j in range(i+i, max, i): # percorro tutto _primes dalla posizione i * 2 con passo i (scorro tutti i multipli di i)
                _primes[j-2] = False # e metto a false i multipli
    return [i for i in _range if _primes[i-2]] # restituisco una lista con tutti i numeri per cui in _primes c'� true

s1 = sieve(1000)
s2 = sieve("Test")
s3 = sieve(-10)
s4 = sieve(4.0)

print(s1 if len(s1) > 0 else "Impossibile procedere per sieve(1000)")
print(s2 if len(s2) > 0 else 'Impossibile procedere per sieve("Test")')
print(s3 if len(s3) > 0 else "Impossibile procedere per sieve(-10)")
print(s4 if len(s4) > 0 else "Impossibile procedere per sieve(4.0)")
                
