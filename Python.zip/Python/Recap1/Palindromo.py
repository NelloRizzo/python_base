# si vuole scrivere un algoritmo che controlli se una stringa in input � palindroma
#
# cosa significa "stringa palindroma"?
# una stringa � palindroma se si legge allo stesso modo sia da sinistra a destra che
# da destra a sinistra
def palindrome(text):
    rev = text[::-1] # inverte la sequenza di caratteri contenuti dentro "text"
    if rev == text:
        return True
    else:
        return False

w = "non palindroma" 
w = "anna e otto e anna"
w = "itopinieinipoti"
if palindrome(w):
    print(w, " e' palindroma")
else:
    print(w, "non e' palindroma")
