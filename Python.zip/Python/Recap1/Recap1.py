
import datetime
from numbers import Number

from random import randrange

# f(x) = x + 2 => f(1) = 1 + 2 = 3...
def square(n):
    if isinstance(n, Number):
        return n * n
    return -1


def length(s):
    if type(s) is str:
        return len(s)
    if isinstance(s, Number):
        return len(str(s))
    return -1


def random(range):
    return randrange(range)


def test():  # definizione di un nome di funzione
    # corpo della funzione
    print("This is a test")


def salutaPrimaVersione():
    altro_nome = "Topolino"  # questa variabile � definita qui...
    print("Ciao,", nome)
    print("Ciao,", altro_nome)
    # ...e muore qui


#         parametro
#            |
#            V
def saluta(nome):
    if (
        type(nome) is str
    ):  # controlla che il tipo di valore dentro "nome" sia proprio str
        print("Ciao,", nome)
    elif type(nome) is float and nome == 3.14:
        print("Ciao, pigreco")
    else:
        print("Non posso salutarti se non mi dici il tuo nome")


def quadrato(n):
    if isinstance(
        n, Number
    ):  # controlla se "n" � compatibile con il tipo complicato del Python che si chiama Number
        print(n * n)
    else:
        print("Mi serve un numero per procedere")


nome = "Pippo"

test()
test()
test()
test()
salutaPrimaVersione()
nome = "Paperino"
salutaPrimaVersione()

#      argomento
#         |
#         V (in pratica � come se scrivessi che la variabile "nome" interna alla funzione saluta debba essere valorizzata con "Pippo": nome = "Pippo")
saluta("Pippo")
saluta("Pluto")
saluta("Archimede")
saluta(3.14)
saluta(2)
quadrato(3)
quadrato("Pippo")
quadrato(3.14)

print(square(2))
quad = square(2)
print(quad + 1)
print("Lunghezza di Paperino:", length("Paperino"))
print("Lunghezza di 1234:", length(1234))
print("Lunghezza di 1234:", length(4321))
print("Lunghezza di 1234:", length(1234))
print("Lunghezza di 1234:", length(4321))
adesso = datetime.datetime.now()
print("Lunghezza di", adesso, "=", length(adesso))
print(random(100))
print(random(100))