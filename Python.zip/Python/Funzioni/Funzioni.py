from email.policy import strict
import string


print("Ciao a tutti quanti")
#
#
#
print("Ciao a tutti quanti")
print("Ciao a tutti")
print("Ciao a tutti quanti")
#
#
#
print("Ciao a tutti")


# funzione salutaTutti()
def salutaTutti():
    print("Ciao a tutti quanti da salutaTutti()")


print("Qui inizio ad usare salutaTutti()")
salutaTutti()
salutaTutti()
salutaTutti()
salutaTutti()
salutaTutti()
salutaTutti()

nome = "Topolino"
x = 20  # variabile globale


def saluta():
    x = 10  # variabile locale alla funzione saluta()
    print("Ciao,", nome, "qui x vale", x)


saluta()
nome = "Paperino"
saluta()

print("invece nel programma principale x vale ", x)

def salutaSpecial(nome: int):
    # nome = nome + 1 <- se nome � una stringa l'istruzione fallir�
    print("Ciao,", nome)

salutaSpecial("Paperino")
salutaSpecial("Topolino")
salutaSpecial("Archimede")
salutaSpecial(10)