import datetime as dt
#from fiscalcode import fiscal_code
import fiscalcode as fc

print("Esempio sbagliato:", fc.fiscal_code("Marta", "Rossi", dt.datetime(1970, 1, 23), "f", "P000"))
print("Esempio sbagliato:", fc.fiscal_code("Al", "Re", dt.datetime(1970, 7, 23), "m", "P000"))
print("Esempio sbagliato:", fc.fiscal_code("Sala", "De' Crescenzo", dt.datetime(1970, 5, 23), "f", "P000"))
print("Esempio sbagliato:", fc.fiscal_code("Crescenzo", "De' Crescenzo", dt.datetime(1970, 9, 23), "m", "P000"))
print("Silvio Berlusconi:", fc.fiscal_code("Silvio", "Berlusconi", dt.datetime(1936,9,29), "m", "F205"))
print("Matteo Renzi:", fc.fiscal_code("Matteo", "Renzi", dt.datetime(1975,1,11), "m", "D612"))
print("Elly Schlein:", fc.fiscal_code("Elena Ethel", "Schlein", dt.datetime(1985,5,4), "f", "Z133"))
print("Giorgia Meloni:", fc.fiscal_code("Giorgia", "Meloni", dt.datetime(1977,1,15), "f", "H501"))
