import datetime as dt


def fiscal_code(first_name: str, last_name: str, birthday: dt.datetime, gender: str, birth_city: str) -> str:
    if type(first_name) is not str or type(last_name) is not str:
        return "Occorre fornire nome e cognome come stringa"
    if type(birth_city) is not str:
        return "Occorre fornire il nome della citta' di nascita"
    if (type(gender) is not str or len(gender) > 1
            or (gender != "m" and gender != "f")):
        return "Il valore per il sesso puo' essere soltanto 'm' o 'f'"
    if not type(birthday) is dt.datetime:
        return "La data di nascita non e' del tipo corretto (datetime)"
    cf = (__handle_last_name(last_name) + __handle_first_name(first_name) +
          __handle_birthday(birthday, gender) +
          __handle_birth_city(birth_city))
    return cf + __calculate_check_code(cf)


# Estrae le consonanti e le vocali da una stringa in input.
# Ho scelto di restituire le consonanti e le vocali dentro una tupla, in cui
# il primo elemento sono tutte le consonanti e il secondo sono tutte le vocali.
def __cons_vowels(t: str) -> tuple:
    # innanzitutto metto la stringa in maiuscolo
    t = t.upper()
    # recupero le vocali
    v = [  # � una lista!
        c for c in t  # attraverso la stringa "t"
        # e prelevo solo le vocali (nell'ordine in t)
        if c == "A" or c == "E" or c == "I" or c == "O" or c == "U"
    ]
    # recupero le consonanti
    c = [c for c in t  # attraverso la stringa "t"
         if c in "BCDFGHJKLMNPQRSTVWXYZ"  # e prendo solo le consonanti
         ]
    return ("".join(c)  # trasforma la lista c in una stringa
            , "".join(v)  # trasforma la lista v in una stringa
            )


# Sono necessari 3 caratteri per rappresentare il cognome,
# e sono la prima la seconda e la terza consonante del cognome.
# E' possibile che le consonanti siano meno di tre, in questo caso � possibile aggiungere le vocali
# nell'ordine in cui compaiono nel cognome.
# Per cognomi pi� corti di 3 caratteri, � possibile sostituire il carattere mancante con la lettera X.
# Chiaramente se ci sono cognomi con pi� parti,
# � necessario rimuovere gli spazi e considerare tutto come un cognome unico.
#
# Per poter risolvere questo problema ho innanzitutto una necessit�: dal cognome
# devo estrarre le consonanti e le vocali, perch� potrebbero servire entrambe (sicuramente servono le consonanti!)
def __handle_last_name(l: str) -> str:
    cons, vow = __cons_vowels(l)
    # creo una stringa concatenando consonanti + vocali + XXX
    return (cons + vow + "XXX")[:3]  # e restituisco i primi 3 caratteri

# Per il nome il discorso � analogo al cognome con la particolarit� che
# se il nome � composto da 4 o pi� consonanti vengono prese nell'ordine la prima, la terza e la quarta.
# Anche qui potremmo trovarci nella situazione di un numero di consonanti minore di 3
# e allo stesso modo si aggiungo le vocali.
# Ripetiamo anche qui che se il nome � pi� corto di 3 lettere � possibile
# sostituire i caratteri mancanti con delle X.
# Se il nome fosse composto da pi� nomi, bisogna considerarlo tutto assieme.


def __handle_first_name(f: str) -> str:
    c, v = __cons_vowels(f)
    if len(c) > 3:  # se il numero di consonanti � > 3
        c = c[0] + c[2:]  # prendo la prima e le restanti dalla terza in poi
    return (c + v + "XXX")[:3]  # come per il cognome

# Per l'anno vengono prese semplicemente le ultime due cifre.
# Per quanto riguarda il mese c'� una tabella di conversione che riportiamo qui di seguito.
# Ad ogni mese corrisponde una lettera dell'alfabeto: A->gen BCDEHLMPRST -> dic
# Per il giorno � sufficiente riportare il numero del giorno,
# con il particolare che per le donne questo numero dev'essere aumentato di 40!


def __handle_birthday(bd: dt.datetime, g: str) -> str:
    d, m, y = bd.day, bd.month, bd.strftime("%y")

    return (y  # le ultime due cifre dell'anno
            # i mesi vanno da 1 a 12, i caratteri nella stringa da 0 a 11
            + "ABCDEHLMPRST"[m - 1]
            + ("0" # per tranquillit� mia metto all'inizio uno 0 
               + str(  # str converte il contenuto in stringa
                   d  # prendo il giorno come numero
                   # aggiungo 40 se sesso � f, altrimenti aggiungo 0
                   + (40 if g == "f" else 0)
               )  # converto il numero ottenuto in stringa
               )[-2:] # prendo gli ultimi due caratteri della stringa che rappresenta giorno e sesso
            )

# E' composto da quattro caratteri alfanumerici.
# E' il codice del comune rilevati dai volumi dei codici dei comuni italiani.
# Ci sono database che contengono tutti i comuni d'italia con relativi codici.


def __handle_birth_city(c: str) -> str:
    return (c.upper() + "0000")[:4]

# Rimane l'ultimo carattere, � il codice di controllo, 
# forse la procedura pi� noiosa � proprio il calcolo di quest'ultimo carattere.
# Partiamo subito mostrando questa tabella:
# Si comincia con il prendere i caratteri del codice fiscale fin qui calcolato che sono 15, 
# si prendono quelli in posizione pari e si convertono con i numeri corrispondenti della prima tabella. 
# Tutti questi numeri vengono sommati.
# Allo stesso modo con i caratteri dispari che devono essere convertiti per� utilizzando la seconda tabella 
# e vengono tutti sommati.
# I valori ottenuti vengono a loro volta sommati e il totale viene diviso per 26.
# Il resto della divisione dev'essere convertito usando l'ultima tabella.
# Il carattere corrispondente � il codice di controllo!
def __calculate_check_code(f: str) -> str:
    # per i caratteri di posizione pari, ad ogni carattere corrisponde la sua posizione nella sua "famiglia" (cifra o lettera)
    # per i caratteri di posizione dispari, mi sono creato una tabella con il numero associato alla posizione
    # del carattere nella sua "famiglia" di appartenenza
    odds = [1, 0, 5, 7, 9, 13, 15, 17, 19, 21, 2, 4, 18,
            20, 11, 3, 6, 8, 12, 14, 16, 10, 22, 25, 24, 23]
    s = 0 # contiene la somma dei valori associati ai diversi caratteri
    for i in range(0, 15): # i attraversa l'intervallo [0..14]
        c = f[i] # prendo il carattere in posizione i da f
        # ord('0') restituisce il codice ASCII del carattere '0'
        # dentro depl ci sar� la posizione del carattere all'interno della sua famiglia (cifra o lettera)
        depl = ord(c) - (ord("0") if c >= "0" and c <= "9" else ord("A"))
        # per i caratteri di posizione dispari devo leggere il valore dalla lista "odds"
        # per gli altri il valore sar� proprio depl
        # devo solo ricordare che l'algoritmo comincia a contare i caratteri da 1 in poi
        # mentre io comincio a contare da 0
        s += odds[depl] if i % 2 == 0 else depl
        # prendo s, calcolo il resto della divisione per 26 
        # e lo converto in una lettera dell'alfabeto, aggiungendo il codice ASCII del carattere A
        # chr � l'inverso di ord, cio�, dato un numero, restituisce il carattere associato a quel numero
        # all'interno della tabella dei codici ASCII
    return chr(s % 26 + ord("A"))